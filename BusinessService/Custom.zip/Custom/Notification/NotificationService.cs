﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessData.DataContext;
using BusinessData.CommonRepository;
//using AvailAnalytics.Service.Common;
//using System.Data.SqlClient;
//using Microsoft.EntityFrameworkCore;
using BusinessService.Common;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace BusinessService.Custom.Notification
{
   public class NotificationService : EntityService<TblNotification>, INotificationService
    {
        readonly IGenericStoredProcedureRepository<TblNotification> spRepository;
        readonly IGenericRepository<TblNotification> repository;
        readonly IUnitOfWork unitOfWork;



        public NotificationService(IUnitOfWork _unitOfWork, IGenericRepository<TblNotification> _repository, IGenericStoredProcedureRepository<TblNotification> _spRepository)
         : base(_unitOfWork, _repository, _spRepository)
        {
            unitOfWork = _unitOfWork;
            repository = _repository;
            spRepository = _spRepository;

        }

        public async Task<TblNotification> Get(int ID)
        {

            return await repository.SelectById(ID);
        }
        public async Task<bool> tblinsert(TblNotification tbl)
        {
            try
            {
                await Create(tbl);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public async Task<bool> tblupdate(TblNotification tbl)
        {
            try
            {
                await Update(tbl);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public async Task<bool> tbldelete(int id)
        {
            try
            {
                await Delete(await Get(id));
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public async Task<IEnumerable<GetUserLogNotification_Result>> GetTodayNotification()
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetUserLogNotification_Result>("GetUserLogNotification");
        }
        public async Task<IEnumerable<GetUserLogNotification_Result>> GetUserLogNotification()
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetUserLogNotification_Result>("exec GetUserLogNotification");
        }
        public async Task<IEnumerable<GetCurrentMonthBirthDay_Result>> GetCurrentMonthBirthDay()
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetCurrentMonthBirthDay_Result>("exec GetCurrentMonthBirthDay");
        }
        public async Task<IEnumerable<GetVOEventsNotification_Result>> GetVOEventsNotification()
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetVOEventsNotification_Result>("exec GetVOEventsNotification");
        }

        public async Task<IEnumerable<GetEmpLeaveBalance_Result>> GetEmpLeaveBalance(int EID)
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetEmpLeaveBalance_Result>("GetEmpLeaveBalance @eid", new SqlParameter("@eid", EID));
        }

        public async Task<IEnumerable<GetTodayLeaveList_Result>> GetTodayLeaveList()
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetTodayLeaveList_Result>("GetTodayLeaveList");
        }
        public async Task<IEnumerable<GetNotificationDetailByUserID_Result>> GetNotificationDetailByUserID(int UID)
        {
            return await spRepository.ExecWithStoreProcedureAsync<GetNotificationDetailByUserID_Result>("GetNotificationDetailByUserID @UID", new SqlParameter("@UID", UID));
        }
        public async Task<IEnumerable<getclientgraphreport_Result>> GetGraphReport(DateTime FromDate, DateTime ToDate)
        {
            return await spRepository.ExecWithStoreProcedureAsync<getclientgraphreport_Result>("exec getclientgraphreport @startdt,@enddt", new SqlParameter("@startdt", FromDate), new SqlParameter("@enddt", ToDate));
        }
    }
}
